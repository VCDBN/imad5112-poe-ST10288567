package com.example.imad5112_st10288567

import android.annotation.SuppressLint

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.imad5112_st10288567.R
import kotlin.math.abs
import kotlin.math.sqrt

import android.content.Intent


class MainActivity : AppCompatActivity() {

    // Initialize references to UI components
    private lateinit var num1EditText: EditText
    private lateinit var num2EditText: EditText
    private lateinit var resultTextView: TextView
    private lateinit var buttonAdd: Button
    private lateinit var buttonSubtract: Button
    private lateinit var buttonMultiply: Button
    private lateinit var buttonDivide: Button
    private lateinit var buttonClear: Button
    private lateinit var buttonSQUAREROOT: Button
    private lateinit var buttonPOWER: Button
    private lateinit var navButton: Button

    @SuppressLint("SetTextI18n", "CutPasteId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)






        // Initialize ui components
        num1EditText = findViewById(R.id.num1editTextNumber)
        num2EditText = findViewById(R.id.num2editTextNumber)
        resultTextView = findViewById(R.id.editTextNumber)
        buttonAdd = findViewById(R.id.buttonAdd)
        buttonSubtract = findViewById(R.id.buttonSubtract)
        buttonMultiply = findViewById(R.id.buttonMultiply)
        buttonDivide = findViewById(R.id.buttonDivide)
        buttonSQUAREROOT = findViewById(R.id.buttonSQUAREROOT)
        buttonPOWER = findViewById(R.id.buttonPOWER)
        buttonClear = findViewById(R.id.buttonClear)
        navButton = findViewById(R.id.statsNavigate)

        // Set click listeners for operation buttons
        buttonAdd.setOnClickListener {
            val num1 = num1EditText.text.toString().toInt()
            val num2 = num2EditText.text.toString().toInt()
            addition(num1, num2)
        }

        buttonSubtract.setOnClickListener {
            val num1 = num1EditText.text.toString().toInt()
            val num2 = num2EditText.text.toString().toInt()
            subtraction(num1, num2)
        }

        buttonMultiply.setOnClickListener {
            val num1 = num1EditText.text.toString().toInt()
            val num2 = num2EditText.text.toString().toInt()
            multiplication(num1, num2)
        }

        buttonDivide.setOnClickListener {
            val num1 = num1EditText.text.toString().toInt()
            val num2 = num2EditText.text.toString().toInt()
            division(num1, num2)
        }

        buttonSQUAREROOT.setOnClickListener {
            val num1 = num1EditText.text.toString().toInt()
            squareRoot(num1)
        }

        buttonPOWER.setOnClickListener {
            val num1 = num1EditText.text.toString().toInt()
            val num2 = num2EditText.text.toString().toInt()
            val result = power(num1, num2)
            resultTextView.text = "$num1^$num2 = $result"
        }

        // Set click listener for clear button
        val clearButton = findViewById<Button>(R.id.buttonClear)
        clearButton.setOnClickListener {
            num1EditText.setText("")
            num2EditText.setText("")
            resultTextView.text = ""
            Toast.makeText(this, "Cleared", Toast.LENGTH_LONG).show()
        }

        navButton.setOnClickListener {

            val intent = Intent(this,StatisticsActivity::class.java)


            startActivity(intent)
        }
    }

    // Perform addition operation and update resultTextView
    @SuppressLint("SetTextI18n")
    private fun addition(num1: Int, num2: Int) {
        val result = num1 + num2
        resultTextView.text = "Result: $num1 + $num2 = $result"
    }

    // Perform subtraction operation and update resultTextView
    @SuppressLint("SetTextI18n")
    private fun subtraction(num1: Int, num2: Int) {
        val result = num1 - num2
        resultTextView.text = "Result: $num1 - $num2 = $result"
    }

    // Perform multiplication operation and update resultTextView
    @SuppressLint("SetTextI18n")
    private fun multiplication(num1: Int, num2: Int) {
        val result = num1 * num2
        resultTextView.text = "Result: $num1 * $num2 = $result"
    }

    // Perform division operation and update resultTextView
    @SuppressLint("SetTextI18n")
    private fun division(num1: Int, num2: Int) {
        val result = if (num2 != 0) num1.toDouble() / num2.toDouble() else Double.NaN
        resultTextView.text = if (!result.isNaN()) "Result: $num1 / $num2 = $result" else "Error: Division by 0 is not allowed"
    }

    // Perform square root operation and update resultTextView
    @SuppressLint("SetTextI18n")
    private fun squareRoot(num1: Int) {
        val result: String = if (num1 >= 0) {
            val squareRoot = sqrt(num1.toDouble())
            "sqrt($num1) = $squareRoot"
        } else {
            val absNum = abs(num1)
            val imaginaryPart = sqrt(absNum.toDouble())
            "sqrt(-$absNum) = ${imaginaryPart}i"
        }

        result.also { resultTextView.text = it }
    }

    // Calculate the power of a number
    private fun power(base: Int, exponent: Int): Double {
        var result = 1.0
        for (i in 1..exponent) {
            result *= base
        }
        return result
    }
}


//REFERENCE LIST:
//Code done by Darsh somayi
//Link used: Youtube-https://youtu.be/v24Bhk7wQi8?si=QX9yvUE3jiRbd6tp