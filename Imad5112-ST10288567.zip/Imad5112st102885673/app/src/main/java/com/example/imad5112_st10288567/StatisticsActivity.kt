package com.example.imad5112_st10288567

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class StatisticsActivity : AppCompatActivity() {

    private lateinit var textViewNumbers: TextView
    private lateinit var textViewResult: TextView
    private lateinit var buttonClearNumbers: Button
    private lateinit var buttonCalculateAverage: Button
    private lateinit var buttonFindMinMax: Button

    private val numbers = IntArray(10)
    private var count = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_statistics)
        textViewNumbers = findViewById(R.id.textViewNumbers)
        textViewResult = findViewById(R.id.textViewResult)
        buttonClearNumbers = findViewById(R.id.buttonClearNumbers)
        buttonCalculateAverage = findViewById(R.id.buttonCalculateAverage)
        buttonFindMinMax = findViewById(R.id.buttonFindMinMax)

        buttonClearNumbers.setOnClickListener {
            clearNumbers()
        }

        buttonCalculateAverage.setOnClickListener {
            calculateAverage()
        }

        buttonFindMinMax.setOnClickListener {
            findMinMax()
        }
    }

    private fun clearNumbers() {
        count = 0
        for (i in numbers.indices) {
            numbers[i] = 0
        }
        updateTextViewNumbers()
        textViewResult.text = ""
    }

    private fun calculateAverage() {
        if (count == 0) {
            textViewResult.text = "No numbers entered."
            return
        }

        var sum = 0
        for (i in 0 until count) {
            sum += numbers[i]
        }

        val average = sum.toDouble() / count.toDouble()
        textViewResult.text = "Average: $average"
    }

    private fun findMinMax() {
        if (count == 0) {
            textViewResult.text = "No numbers entered."
            return
        }

        var min = numbers[0]
        var max = numbers[0]

        for (i in 1 until count) {
            if (numbers[i] < min) {
                min = numbers[i]
            }

            if (numbers[i] > max) {
                max = numbers[i]
            }
        }

        textViewResult.text = "Min: $min, Max: $max"
    }

    private fun updateTextViewNumbers() {
        val numbersText = numbers.take(count).joinToString(", ")
        textViewNumbers.text = "Numbers: $numbersText"
    }

    
}